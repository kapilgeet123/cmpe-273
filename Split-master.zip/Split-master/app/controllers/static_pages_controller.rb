class StaticPagesController < ApplicationController

  def home

  end
  
end
